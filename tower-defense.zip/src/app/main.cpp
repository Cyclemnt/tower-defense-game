#include "engine/gameManager.hpp"

int main() {
    tdg::engine::GameManager gameManager;
    
    return 0;
}
