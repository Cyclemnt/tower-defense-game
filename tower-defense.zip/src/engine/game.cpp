#include "engine/game.hpp"
#include "infrastructure/aStarPathfinder.hpp"

namespace tdg::engine {

    Game::Game(std::shared_ptr<IMapSource> mapSrc, std::shared_ptr<IWaveSource> waveSrc, unsigned int startCores, Materials startMaterials)
        : m_player(startMaterials), m_cores(startCores),
        m_map(std::make_unique<tdg::core::Map>(mapSrc)),
        m_pathfinder(std::make_unique<tdg::infra::AStarPathfinder>(*m_map)),
        m_waveManager(std::make_unique<tdg::core::WaveManager>(waveSrc)),
        m_creatureManager(m_events, *m_map, *m_pathfinder, m_cores, m_player),
        m_towerManager(m_events, *m_map, m_player, m_creatureManager.creatures()),
        m_vfxManager(),
        m_sfxManager(m_events.sfxs)
    {
        m_map->setCoreStorageFillRatioRequest([this](){ return m_cores.ratio(); });
    }

    void Game::update(float dt) {
        ++m_tick;

        // Update WaveManager
        m_waveManager->update(dt, m_events);

        // Create and update VFXs
        m_vfxManager.update(dt, m_events);

        // Create and update creatures
        m_creatureManager.update(dt, m_events);
        
        // Update towers
        m_towerManager.update(dt, m_events);

        // If no creatures left, load next wave
        if (isWaveOver() && m_waveManager->timeBeforeNext() <= 0.0f) {
            m_waveManager->loadNext();
            m_events.sfxs.emplace(Events::NewSFX::Type::NextWave);
        }
    }

    void Game::renderVideo(IVideoRenderer& vidRenderer) const {
        m_map->draw(vidRenderer);

        const std::vector<Renderable>& renderables;
// How?
        renderables.push_back(m_creatureManager.creatures());


        m_creatureManager.renderVideo(vidRenderer);
        m_vfxManager.renderVideo(vidRenderer);
        m_towerManager.renderVideo(vidRenderer);
    }

    void Game::renderAudio(IAudioRenderer& audRenderer) {
        m_sfxManager.renderAudio(audRenderer);
    }

    bool Game::buildTower(std::string towerType, int x, int y) {
        bool towerBuilt = false;
        if (towerType == "Gatling") towerBuilt = m_towerManager.buildTower(Tower::Type::Gatling, x, y);
        if (towerType == "Mortar") towerBuilt = m_towerManager.buildTower(Tower::Type::Mortar, x, y);
        if (towerType == "Laser") towerBuilt = m_towerManager.buildTower(Tower::Type::Laser, x, y);
        if (towerBuilt) m_creatureManager.updatePaths();
        return towerBuilt;
    }

    bool Game::upgradeTower(int x, int y) {
        bool towerUpgraded = false;
        towerUpgraded = m_towerManager.upgradeTower(x, y);
        return towerUpgraded;
    }

    bool Game::sellTower(int x, int y) {
        bool towerSold = false;
        towerSold = m_towerManager.sellTower(x, y);
        if (towerSold) m_creatureManager.updatePaths();
        return towerSold;
    }
    
    bool Game::isWaveOver() const { return m_creatureManager.isWaveOver(); }
    bool Game::isGameOver() const { return m_cores.allLost(); }
    bool Game::isVictory() const { return m_waveManager->allWavesSpawned() && isWaveOver() && !isGameOver(); }

    /* Everything after this is an answer to bad time management, this is very ugly */
    
    GameView Game::getView() const {
        return {
            m_player.materials(),
            m_cores.safeCount(), m_cores.stolenCount(), m_cores.lostCount(),
            m_waveManager->waveIndex(), m_waveManager->waveCount(), m_waveManager->timeBeforeNext()
        };
    }

    bool Game::canAfford(std::string towerType) const {
        std::optional<Materials> cost = towerCost(towerType);
        if (cost.has_value()) return m_player.canAfford(cost.value());
        else return false;
    }

    std::optional<float> Game::towerRangeAt(int x, int y) const {
        return m_towerManager.towerRangeAt(x, y);
    }

    bool Game::tileOpenAt(int x, int y) const {
        Tile* tile = m_map->tileAt(x, y);
        if (!tile) return false;
        if (tile->type == Tile::Type::Open) return true;
        else return false;
    }

    bool Game::towerAt(int x, int y) const {
        Tile* tile = m_map->tileAt(x, y);
        if (!tile) return false;
        if (tile->hasTower) return true;
        else return false;
    }

    std::optional<Materials> Game::towerCost(std::string towerType) const {
        if (towerType == "Gatling") return TowerFactory::getCost(Tower::Type::Gatling);
        if (towerType == "Mortar") return TowerFactory::getCost(Tower::Type::Mortar);
        if (towerType == "Laser") return TowerFactory::getCost(Tower::Type::Laser);
        return std::nullopt;
    }

} // tdg::engine