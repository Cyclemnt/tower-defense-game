#ifndef RENDERABLE_HPP
#define RENDERABLE_HPP

namespace tdg::core { class IVideoRenderer; }

namespace tdg::core {
    
    class Renderable {
    public:
        virtual int zOrder() const noexcept = 0;
        virtual void draw(IVideoRenderer& vidRenderer) const = 0;
    };

} // namespace tdg::core

#endif // RENDERABLE_HPP